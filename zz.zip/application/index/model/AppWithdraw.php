<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/11
 * Time: 11:16
 */

namespace app\index\model;


use think\Model;

class AppWithdraw extends Model
{

}