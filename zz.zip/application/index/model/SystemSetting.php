<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/12
 * Time: 12:47
 */

namespace app\index\model;


use think\Model;

class SystemSetting extends Model
{

}