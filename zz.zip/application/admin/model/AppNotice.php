<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/13
 * Time: 15:04
 */

namespace app\admin\model;


use think\Model;

class AppNotice extends Model
{

}