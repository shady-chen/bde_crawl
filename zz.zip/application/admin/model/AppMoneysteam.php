<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/30
 * Time: 15:18
 */
namespace app\admin\model;


use think\Model;

class AppMoneysteam extends Model
{

}