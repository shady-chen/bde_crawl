<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/11
 * Time: 11:16
 */

namespace app\user\model;


use think\Model;

class AppUser extends Model
{

}